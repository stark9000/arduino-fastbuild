Test project for the Explorer tab's error-highlighting feature
================================================================

What's here
-----------
error_test_sketch.ino  - main sketch, has 2 intentional errors + 1 warning
helper.h                - a header, no errors
helper.cpp              - a second source file, has 1 intentional error

This deliberately spans multiple files so you can check that opening a
build with errors in more than one file works correctly - not just the
main .ino, but the separate .cpp too.

How to use it
-------------
1. Point the Project tab at error_test_sketch.ino.
2. Pick any board that doesn't need anything special - Arduino Uno or
   Nano is the simplest choice (arduino:avr:uno / arduino:avr:nano).
   Apply it to the project.
3. Run Build. It should fail (that's expected) with output roughly like:

   error_test_sketch.ino:9:29: error: expected ';' before ...
   error_test_sketch.ino:15:9: error: 'undeclaredDelayTime' was not declared...
   error_test_sketch.ino:19:7: warning: unused variable 'unusedVariable'
   helper.cpp:7:35: error: expected ';' before ...

4. On the Explorer tab, you should see:
   - error_test_sketch.ino open and highlighted at both error lines (9
     and 15) and the warning line (19), in different colors
   - helper.cpp also automatically opened, with its own error line (7)
     highlighted
   - the editor jumped to and selected the FIRST error it found

What each error actually is (in case you want to fix them and see a
clean build afterward)
---------------------------------------------------------------------
- error_test_sketch.ino line 9:  missing semicolon after
  "pinMode(ledPin, OUTPUT)" - add a ; at the end of the line.
- error_test_sketch.ino line 15: "undeclaredDelayTime" isn't a real
  variable - replace it with a number, e.g. delay(500);
- error_test_sketch.ino line 19: "unusedVariable" is declared but never
  used - this is only a warning, the build won't fail because of it, but
  it's useful for checking the warning highlight color looks different
  from the error highlight color. Delete the line, or use the variable
  somewhere, to clear it.
- helper.cpp line 7: missing semicolon after
  Serial.println("Helper called") - add a ; at the end of the line.

Fixing all three errors (the warning is optional) should give you a
clean, successful build - a good way to confirm the error highlights
also clear correctly once the problems are gone.
