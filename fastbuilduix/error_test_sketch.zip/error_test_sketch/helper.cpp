// This file has ONE intentional compile error - see README.txt for details.

#include "helper.h"
#include <Arduino.h>

void callHelperFunction() {
  Serial.println("Helper called")  // <-- ERROR: missing semicolon (line 7)
}
