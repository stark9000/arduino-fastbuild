// Test sketch for the Explorer tab's error-highlighting feature.
// This file has TWO intentional compile errors and ONE warning - see
// README.txt in this folder for exactly what to expect and where.

#include "helper.h"

int ledPin = 13;

void setup() {
  pinMode(ledPin, OUTPUT)   // <-- ERROR: missing semicolon (line 9)
  Serial.begin(9600);
}

void loop() {
  digitalWrite(ledPin, HIGH);
  delay(undeclaredDelayTime);  // <-- ERROR: undeclared identifier (line 15)
  digitalWrite(ledPin, LOW);
  delay(500);

  int unusedVariable = 42;  // <-- WARNING: unused variable (line 19)

  callHelperFunction();
}
